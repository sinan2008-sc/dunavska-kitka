# Дунавска китка — GitHub Pages

Публичната част на сайта е Vite/React приложение за GitHub Pages. Съдържанието, формулярите и анкетите използват съществуващия Sites сървър. Админ панелът остава на `/admin` в Sites.

## Публикуване

1. Качете файловете в GitHub хранилище в клона `main`.
2. В Settings → Pages изберете GitHub Actions.
3. В Settings → Secrets and variables → Actions → Variables добавете `API_ORIGIN` със стойност `https://dunavska-kitka.theslayer31.chatgpt.site`.
4. Публикувайте сървърните промени от `backend-integration.patch` към изходния код на Sites и задайте `PUBLIC_SITE_ORIGIN` на `https://<потребител>.github.io` (само origin, без името на хранилището).
5. Направете Sites сайта публично достъпен, за да може GitHub Pages да чете данните. Админ операциите остават ограничени до профила на собственика.

Workflow-ът компилира при push към `main`. За проектно хранилище URL е `https://<потребител>.github.io/<хранилище>/`.

## Разработка

`pnpm install --frozen-lockfile` и `pnpm dev`. Публичният API адрес може да се промени чрез `VITE_API_ORIGIN` при компилиране.
